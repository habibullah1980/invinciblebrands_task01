<?php
// die();
add_action( 'init', 'newsletter_init' );
function newsletter_init() {
	$labels = array(
		'name'               => _x( 'Newsletters', ' ', ' ' ),
		'singular_name'      => _x( 'Newsletter', '', ' ' ),
		'menu_name'          => _x( 'Newsletters', 'admin menu', ' ' ),
		'name_admin_bar'     => _x( 'Newsletter', 'add new on admin bar', ' ' ),
		'add_new'            => _x( 'Add New', 'Newsletter', ' ' ),
		'add_new_item'       => __( 'Add New Newsletter', ' ' ),
		'new_item'           => __( 'New Newsletter', ' ' ),
		'edit_item'          => __( 'Edit Newsletter', ' ' ),
		'view_item'          => __( 'View Newsletter', ' ' ),
		'all_items'          => __( 'All Newsletters', ' ' ),
		'search_items'       => __( 'Search Newsletters', ' ' ),
		'parent_item_colon'  => __( 'Parent Newsletters:', ' ' ),
		'not_found'          => __( 'No Newsletters found.', ' ' ),
		'not_found_in_trash' => __( 'No Newsletters found in Trash.', ' ' )
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __( 'Description.', ' ' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'newsletter' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
	);

	register_post_type( 'newsletter', $args );
}
function nl_shortcode($atts) {
   $atts = shortcode_atts(
		array(
			'palcement' => '',
		), $atts, 'nl' );
switch ($atts['palcement']) {
    case "footer":
        return ' <form class="newsletter_'.$atts['palcement'].'" method="post" name="nlform" action="#">
    <h2>Newsletter Subscription</h2>
    <input type="text"  placeholder="Name" name="nlformname" required>
    <input type="email" name="nlformemail" placeholder="Email"  required>
    <input class="btn_'.$atts['palcement'].'" type="submit" name="nlformbtm" value="Subscribe">
</form> ';
        break;
    default:
        return ' <form class="newsletter_page" method="post" name="nlform" action="#">
    <h2>Newsletter Subscription</h2>
    <input type="text"  placeholder="Name" name="nlformname" required>
    <input type="email" name="nlformemail" placeholder="Email"  required>
    <input class="btn_'.$atts['palcement'].'" type="submit" name="nlformbtm" value="Subscribe">
</form> ';
}

}
add_shortcode( 'nl', 'nl_shortcode' );
function submiting_nl_form() {
    if(isset($_POST['nlformbtm'])) {
    $my_post = array(
        'post_type' => 'newsletter',
        'post_title'    => wp_strip_all_tags( $_POST['nlformname'] ),
        'post_content'  => $_POST['nlformemail'],
        'post_status'   => 'draft',
        'post_author'   => 1,
);
 
// Insert the post into the database
wp_insert_post( $my_post );
    } 
}
add_action('init', 'submiting_nl_form');


add_action('storefront_footer', 'footer_newsletter_p');
function footer_newsletter_p() {
echo do_shortcode('[nl palcement = "footer"] '); }
 ?>


